.import "../../ui/js/Mounts.js" as Mounts
.import "../../ui/js/RailMenu.js" as RailMenu
.import "../../ui/js/Eject.js" as Eject
.import "../../ui/js/Protocols.js" as Protocols

// Issue #36 (@janoguerra): every network decision resolves from the mount's own URI, or from gio
// output ui/NetworkMounts.qml pins to the C locale, and never from a sentence gvfsd translated.
function run(check) {
    // gio mount -l, the live 2026-08-31 shape ui/js/Mounts.js "parseMounts" records, with gvfsd's
    // own label in Spanish: the daemon composed that label, so no client locale can change it.
    var spanish = 'Mount(0): isos en 192.168.1.10 -> smb://192.168.1.10/isos/\n'
    check("a translated mount label still names the share", Mounts.parseMounts(spanish)[0].label, "isos")
    var english = 'Mount(0): isos on 192.168.1.10 -> smb://192.168.1.10/isos/\n'
    check("and the English one still names it too", Mounts.parseMounts(english)[0].label, "isos")
    var french = 'Mount(0): isos sur nas -> smb://nas/isos/\n'
    check("and so does a third language", Mounts.parseMounts(french)[0].label, "isos")

    // The control the old rule failed: it cut at the English word "on" without ever testing that the
    // tail was this URI's host, so a mount whose own name carries that word lost half of itself.
    var onTuesday = 'Mount(0): backup on tuesday -> smb://nas/backup%20on%20tuesday/\n'
    check("a label that merely contains the word on keeps all of it",
          Mounts.parseMounts(onTuesday)[0].label, "backup on tuesday")
    var onTuesdayOnNas = 'Mount(0): backup on tuesday on nas -> smb://nas/backup%20on%20tuesday/\n'
    check("and loses only the host when it really is share-on-host",
          Mounts.parseMounts(onTuesdayOnNas)[0].label, "backup on tuesday")
    // A phone's shadow mount is DEVICES territory: ui/js/Phones.js builds its row off the volume
    // block, so parseMounts skips the uri the way it already skips file://.
    var phone = 'Mount(0): Pixel 7 -> mtp://Google_Pixel_7_1A2B/\n'
    check("an mtp mount is a phone row's shadow, not a share", Mounts.parseMounts(phone).length, 0)
    var mediaLibrary = 'Mount(0): media library -> dav://nas.local/media/\n'
    check("a label that is not share-on-host keeps the name gio gave it",
          Mounts.parseMounts(mediaLibrary)[0].label, "media library")
    var bareRoot = 'Mount(0): nas -> smb://nas/\n'
    check("a server root's own name is never cut down to nothing",
          Mounts.parseMounts(bareRoot)[0].label, "nas")
    var sameName = 'Mount(0): nas on nas -> smb://nas/nas/\n'
    check("a share named after its own host still loses only the host",
          Mounts.parseMounts(sameName)[0].label, "nas")
    // Two more the fix round found in the fix: a tail that only happens to be the host with no
    // separator at all, and a label whose separator word has nothing in front of it.
    var glued = 'Mount(0): isosnas -> smb://nas/isos/\n'
    check("a label that merely ends in the host, with no separator, is not cut",
          Mounts.parseMounts(glued)[0].label, "isosnas")
    var nothingBefore = 'Mount(0): on nas -> smb://nas/on/\n'
    check("and one with nothing before the separator keeps every character",
          Mounts.parseMounts(nothingBefore)[0].label, "on nas")
    // hostOf keeps a bracketed IPv6 authority whole, and no gio label ends in the brackets, so the
    // tail check cannot fire: a wrong label, never a wrong destination, pinned rather than assumed.
    var literal = 'Mount(0): isos en fe80::1 -> smb://[fe80::1]/isos/\n'
    check("a bracketed IPv6 mount keeps the whole label gio gave it",
          Mounts.parseMounts(literal)[0].label, "isos en fe80::1")

    // The host the label is measured against comes out of the URI's authority, which stops at the
    // first slash: a "@" or a ":" further along belongs to the path and is not a host or a port.
    check("the authority stops at the first slash, so a path never supplies a host",
          Protocols.hostOf("sftp://u@h:22/inbox@2026"), "h")
    check("a bracketed IPv6 literal survives whole", Protocols.hostOf("smb://[fe80::1]:445/isos/"), "[fe80::1]")
    check("a domain-qualified SMB user is not the host", Protocols.hostOf("smb://WORK;gm@nas/isos/"), "nas")
    check("a uri with no authority has no host at all", Protocols.hostOf("file:///home/gm"), "")
    check("no uri at all has no host rather than throwing", Protocols.hostOf(null), "")

    // Sample input: gio info under the C locale ui/NetworkMounts.qml pins, one resolver for the
    // product and for this suite, so the wording lives in exactly one place.
    var info = 'uri: smb://192.168.1.10/isos/\n'
             + 'local path: /run/user/1000/gvfs/smb-share:server=192.168.1.10,share=isos\n'
             + 'unix mount: gvfsd-fuse\n'
    check("the FUSE path comes out of gio's own C-locale line",
          Mounts.localPath(info), "/run/user/1000/gvfs/smb-share:server=192.168.1.10,share=isos")
    check("a location with no FUSE path answers nothing rather than undefined",
          Mounts.localPath('uri: smb://nas/\ntype: directory\n'), "")
    check("no gio output at all answers nothing rather than throwing", Mounts.localPath(""), "")
    // What the LC_ALL=C pin on ui/NetworkMounts.qml "gioEnvironment" is for, named rather than cited
    // by line, because the extraction moved that line and the citation went stale: gio's own wording
    // is the client's, so without the pin the same location answers a line this cannot read and the
    // share resolves to no folder at all. gvfsd's strings above are the daemon's and stay put.
    var translated = 'uri: smb://192.168.1.10/isos/\n'
                   + 'ruta local: /run/user/1000/gvfs/smb-share:server=192.168.1.10,share=isos\n'
    check("a translated gio info carries no path this can read, which is why gio is pinned to C",
          Mounts.localPath(translated), "")

    // PR #21 (@TomFaulkner): one rail row per share, however the port is spelled. "gio mount -l"
    // never reports a scheme's default port, while the add form spells out the one it prefilled.
    check("a default port is not part of the canonical form",
          Mounts.normalize("smb://nas:445/isos/"), "smb://nas/isos")
    check("so a bookmark and a live mount of one share resolve to one rail row",
          Mounts.normalize("smb://nas:445/isos/") === Mounts.normalize("smb://nas/isos/"), true)
    check("a port the scheme would not have used stays",
          Mounts.normalize("smb://nas:4450/isos/"), "smb://nas:4450/isos")
    check("a bare root keeps its own single slash after the port goes",
          Mounts.normalize("smb://nas:445"), "smb://nas/")
    // The defect the contribution itself introduced: a lastIndexOf("@") over the whole URI reads a
    // path's own "@" as the authority, leaves the :22 standing, and answers two rows for one share.
    check("an at sign further along the path is never read as the authority",
          Mounts.normalize("sftp://u@h:22/inbox@2026"), "sftp://u@h/inbox@2026")

    // PR #21: the rail takes live mounts first and skips a bookmark whose key it already has, so the
    // bookmark's own label was thrown away. A rename typed on a mounted share was written to the file
    // and reverted on the next five second poll with nothing said; the name the operator gave wins now.
    var bookmarked = Mounts.nonFileBookmarks("smb://nas:445/isos NAS isos\nsmb://other/data Other\n")
    check("the name the operator gave a place wins on the row its live mount draws",
          Mounts.railLabel({ label: "isos", uri: "smb://nas/isos/" }, bookmarked), "NAS isos")
    check("and it matches however the two spell the port, the way the rail's own dedup does",
          Mounts.railLabel({ label: "isos", uri: "smb://nas:445/isos" }, bookmarked), "NAS isos")
    check("a live mount nothing has bookmarked keeps the name gio gave it",
          Mounts.railLabel({ label: "isos", uri: "smb://third/isos/" }, bookmarked), "isos")
    check("and with no saved places at all it keeps that name too, rather than nothing",
          Mounts.railLabel({ label: "isos", uri: "smb://nas/isos/" }, []), "isos")
    // The shape Nautilus writes for a share nobody renamed, a uri and no name: nonFileBookmarks
    // falls back to the leaf, so the row it wins is never a nameless one.
    var unlabelled = Mounts.nonFileBookmarks("smb://nas/isos\n")
    check("a bookmarks line with no name at all still names the place",
          unlabelled[0].label + "|" + Mounts.railLabel({ label: "gio name", uri: "smb://nas/isos/" }, unlabelled),
          "isos|isos")

    check("a bracketed IPv6 host whose own digits end in the port keeps them",
          Protocols.stripDefaultPort("smb://[fe80::445]/isos/"), "smb://[fe80::445]/isos/")
    check("but a real port after the bracket goes",
          Protocols.stripDefaultPort("smb://[fe80::1]:445/isos/"), "smb://[fe80::1]/isos/")
    // Every port here is one gvfs 1.60.2 drops itself, measured on this box by round-tripping each
    // spelling through Gio.File, the uri mapper "gio mount -l" prints a mount through.
    check("every scheme drops the port gio drops",
          [Protocols.stripDefaultPort("smb://h:445/x"), Protocols.stripDefaultPort("sftp://h:22/x"),
           Protocols.stripDefaultPort("ftp://h:21/x"), Protocols.stripDefaultPort("ftps://h:21/x"),
           Protocols.stripDefaultPort("dav://h:80/x"), Protocols.stripDefaultPort("davs://h:443/x")].join("|"),
          "smb://h/x|sftp://h/x|ftp://h/x|ftps://h/x|dav://h/x|davs://h/x")
    // The same measurement the other way: gio keeps a port that is not that scheme's own, so
    // stripping one here would answer a rail key no gio listing can match.
    check("a port another scheme calls default is kept, because gio keeps it",
          [Protocols.stripDefaultPort("dav://h:443/x"), Protocols.stripDefaultPort("davs://h:80/x"),
           Protocols.stripDefaultPort("ftps://h:990/x")].join("|"),
          "dav://h:443/x|davs://h:80/x|ftps://h:990/x")
    // gvfs canonicalises no nfs port, so the two spellings really can differ; 2049 stays because it
    // is the port an nfs client uses when the line omits one.
    check("an nfs line and an nfs mount are one row however 2049 is spelled",
          Mounts.normalize("nfs://h:2049/export") === Mounts.normalize("nfs://h/export"), true)
    // Built by the form's own uri(), so the check cannot drift from what the dialog writes: WebDAV
    // picked, the box as given, and the prefilled port dropped back off because it is the one that
    // scheme would have used anyway, which is the shape the operator gets.
    function formUri(tls) {
        return Protocols.uri({ protocol: "WebDAV", host: "nas.local", path: "/dav", user: "",
                               domain: "", tls: tls, port: String(Protocols.defaultPort("WebDAV", tls)) })
    }
    check("the form omits a port the scheme it built already uses, either way the box is set",
          formUri(false) + "|" + formUri(true), "dav://nas.local/dav|davs://nas.local/dav")
    // Each is now its own scheme's default, so gio drops it from the mount it reports and the
    // dedup drops it from the line; the bookmark and the live mount are one row on both spellings.
    check("so plain WebDAV's bookmark and gio's own report of it are one rail row",
          Mounts.normalize(formUri(false)) === Mounts.normalize("dav://nas.local/dav/"), true)
    // And the cost of the change, stated rather than left implicit: a line an older build wrote with
    // the protocol-keyed prefill still carries 443, which gio keeps on plain dav, so it is its own row.
    check("a plain-dav line still spelling 443 is a row of its own, because gio keeps that port",
          Mounts.normalize("dav://nas.local:443/dav") === Mounts.normalize("dav://nas.local/dav/"), false)
    check("and so are TLS WebDAV's, which was already the case",
          Mounts.normalize(formUri(true)) === Mounts.normalize("davs://nas.local/dav/"), true)
    check("and never drops another scheme's default", Protocols.stripDefaultPort("sftp://h:445/x"), "sftp://h:445/x")
    check("text that is not a uri at all is left alone", Protocols.stripDefaultPort("/home/gm"), "/home/gm")

    // The rail menu the right click opens, which is not the release verdict ui/js/Eject.js reads:
    // Ctrl+E must still refuse a row with nothing mounted rather than starting an editor on it.
    var mounted = { path: "", label: "isos", group: "network", kind: "share", uri: "smb://nas/isos/", mounted: true }
    var saved = { path: "", label: "NAS", group: "network", kind: "share", uri: "smb://nas/", mounted: false }
    var volume = { path: "/run/media/gm/128GB", label: "128GB", group: "device", kind: "volume", device: "/dev/sda1", mounted: true, removable: true }
    var favourite = { path: "/home/gm", label: "Home", group: "favourite", kind: "favourite", mounted: false }
    function labels(rows) { return rows.filter(function (r) { return !r.separator }).map(function (r) { return r.label }).join("|") }
    check("a mounted share releases first, then offers the three the place itself owns", labels(Mounts.rowMenu(mounted)), "Open|Unmount|Rename|Edit address|Remove from Network")
    check("and Ctrl+E picks the release out of those rows, never the first one", Eject.releaseFromRows(Mounts.railMenu(mounted)), "unmount")
    check("a bookmark nothing has mounted offers the three that need no mount",
          labels(Mounts.rowMenu(saved)), "Rename|Edit address|Remove from Network")
    check("so it opens a menu where it used to open an empty one", Mounts.rowMenu(saved).filter(function (r) { return !r.separator }).length, 3)
    check("but it has nothing to release, so Ctrl+E still says so", Eject.releaseFromRows(Mounts.railMenu(saved)), "")
    check("a removable volume offers Open, Unmount, Eject and Flash image", labels(Mounts.rowMenu(volume)), "Open|Unmount|Eject|Flash image")
    check("and Ctrl+E picks Eject out of it", Eject.releaseFromRows(Mounts.railMenu(volume)), "eject")
    // With showUnmounted on a removable volume offers both releases, and Ctrl+E takes Eject first.
    var bothVolume = { path: "/run/media/gm/128GB", label: "128GB", group: "device", kind: "volume", device: "/dev/sda1", mounted: true, removable: true }
    function entries(rows) { return rows.map(function (r) { return r.separator ? "-" : r.label }).join("|") }
    check("a volume offering both releases draws Open, Unmount, Eject and Flash image",
          entries(Mounts.rowMenu(bothVolume)), "Open|-|Unmount|Eject|-|Flash image")
    check("railMenu offers Ctrl+E those same rows", entries(Mounts.railMenu(bothVolume)), "Open|-|Unmount|Eject|-|Flash image")
    check("and Ctrl+E picks eject over unmountVolume", Eject.releaseFromRows(Mounts.railMenu(bothVolume)), "eject")
    check("a favourite offers INVENTORY's own Remove from Favorites", labels(Mounts.rowMenu(favourite)), "Remove from Favorites")
    check("no entry at all offers nothing rather than throwing", Mounts.rowMenu(null).length, 0)
    check("Remove from Network draws the minus mark, because forgetting a place trashes nothing",
          Mounts.rowMenu(saved).filter(function (r) { return !r.separator })[2].glyph, "minus")
    // Issue 21, TomFaulkner: Rename is the label and Edit address is the address, so they are two rows.
    check("Rename is offered before Edit address, and the address is what it changes",
          Mounts.rowMenu(saved).filter(function (r) { return !r.separator })[0].action + "|" + Mounts.rowMenu(saved).filter(function (r) { return !r.separator })[1].action, "rename|editPlace")

    // A chosen row arrives as its key, never its position: the rail rebuilds on a five second poll.
    function chose(action, key, entries) {
        var log = []
        var sidebar = { placesEntries: [favourite, { kind: "trash" }], networkEntries: entries, deviceEntries: [volume],
                        startRename: function (i) { log.push("rename" + i) } }
        var mounts = { unmount: function (i) { log.push("unmount" + i) },
                       forget: function (uri) { log.push("forget " + uri) } }
        var devices = { eject: function (i) { log.push("eject" + i) } }
        RailMenu.release(action, key, devices, mounts, sidebar)
        return log.join(",")
    }
    check("Rename resolves the network row past Places, including Trash",
          chose("rename", "smb://nas/", [mounted, saved]), "rename3")
    check("Remove forgets the place by uri and never by position",
          chose("remove", "smb://nas/", [mounted, saved]), "forget smb://nas/")
    check("a key that no longer names a row does nothing at all",
          chose("remove", "smb://gone/", [mounted, saved]), "")
    check("Unmount still resolves through the network Service",
          chose("unmount", "smb://nas/isos/", [mounted, saved]), "unmount0")
    check("Eject still resolves through the device Service",
          chose("eject", "/dev/sda1", [mounted, saved]), "eject0")

    // Issue 21: Edit asks the dialog to open over the place, and only a different address that
    // actually mounted rewrites its line; a refused connect leaves the saved place exactly as it was.
    function edited(uri, success, mountedUri) {
        var asked = []
        var sidebar = { placesEntries: [favourite, { kind: "trash" }], networkEntries: [mounted, saved],
                        deviceEntries: [volume], editingPlace: "", navigationPane: "pane",
                        startRename: function () {},
                        editRequested: function (u, label, password, reason, failed, origin) {
                            asked.push("open " + u + " as " + label + " over " + origin + ": " + reason)
                        } }
        var mounts = { unmount: function () {}, forget: function () {},
                       replacePlace: function (was) { asked.push("replace " + was) } }
        RailMenu.release("editPlace", uri, { eject: function () {} }, mounts, sidebar)
        RailMenu.placeSubmitted(sidebar, "r1")
        RailMenu.placeSaved(sidebar, mounts, "r1", mountedUri, success)
        return asked
    }
    check("Edit opens the dialog over the place, with the line that says what to do",
          edited("smb://nas/", false, "")[0],
          "open smb://nas/ as NAS over pane: Edit this address, then connect and save.")
    check("and the corrected address rewrites that place's own line",
          edited("smb://nas/", true, "smb://nas2/data")[1], "replace smb://nas/")
    check("an address that did not change rewrites nothing",
          edited("smb://nas/", true, "smb://nas/").length, 1)
    check("and a refused connect leaves the saved place alone",
          edited("smb://nas/", false, "smb://nas2/data").length, 1)

    // A refused connect is what this feature exists for, so the arm survives it: the same dialog is
    // still open, and the attempt that finally mounts is the one that rewrites the line.
    var armed = { placesEntries: [favourite, { kind: "trash" }], networkEntries: [mounted, saved],
                  deviceEntries: [volume], editingPlace: "", navigationPane: "pane",
                  startRename: function () {}, editRequested: function () {} }
    var wrote = []
    var writer = { unmount: function () {}, forget: function () {},
                   replacePlace: function (was) { wrote.push(was) } }
    RailMenu.release("editPlace", "smb://nas/", { eject: function () {} }, writer, armed)
    // Only this edit's own attempt answers for it: a mount in flight when the rail armed carries
    // another request, and so does one started from the dialog after this attempt was refused.
    RailMenu.placeSaved(armed, writer, "older-request", "smb://stranger/share", true)
    check("a mount already in flight when Edit armed rewrites nothing", wrote.join(","), "")
    RailMenu.placeSubmitted(armed, "r0")
    RailMenu.placeSaved(armed, writer, "another-request", "smb://stranger/share", true)
    check("and neither does one that is not the attempt this dialog made", wrote.join(","), "")
    check("both of which leave the place armed", armed.editingPlace, "smb://nas/")
    RailMenu.placeSubmitted(armed, "r1")
    RailMenu.placeSaved(armed, writer, "r1", "smb://nas2/data", false)
    check("a refused attempt keeps the place armed", armed.editingPlace, "smb://nas/")
    RailMenu.placeSubmitted(armed, "r2")
    RailMenu.placeSaved(armed, writer, "r2", "smb://nas2/data", true)
    check("and the attempt that mounts is the one that rewrites it", wrote.join(","), "smb://nas/")
    check("which disarms it, so a later unrelated mount rewrites nothing", armed.editingPlace, "")
    RailMenu.placeSaved(armed, writer, "r3", "smb://stranger/share", true)
    check("proved by that later mount", wrote.join(","), "smb://nas/")
    // ui/WindowBody.qml clears editingPlace when the dialog closes, so an abandoned Edit disarms too.
    RailMenu.release("editPlace", "smb://nas/", { eject: function () {} }, writer, armed)
    armed.editingPlace = ""
    RailMenu.placeSubmitted(armed, "r4")
    RailMenu.placeSaved(armed, writer, "r4", "smb://stranger/share", true)
    check("an Edit nobody finished rewrites nothing either", wrote.join(","), "smb://nas/")

    // Sample input: the operator's own bookmarks file, favourites and places in one list.
    var body = "file:///home/gm/Downloads Downloads\nsmb://nas:445/isos NAS isos\nsmb://other/data Other\n"
    check("the place's own line goes and every other byte stays",
          Mounts.removeBookmark(body, "smb://nas/isos/"),
          "file:///home/gm/Downloads Downloads\nsmb://other/data Other\n")
    check("a uri no line carries changes nothing", Mounts.removeBookmark(body, "smb://gone/x"), body)
    check("a line whose uri merely starts with this one is another place and stays",
          Mounts.removeBookmark("smb://nas/isos2 Other\n", "smb://nas/isos"), "smb://nas/isos2 Other\n")
    // nonFileBookmarks trims before it parses, so an indented line is a rail row that matching the
    // raw line here could not remove, under the refusal's mounted-only clause.
    check("an indented line is the row it draws, so Remove reaches it",
          Mounts.removeBookmark("  smb://nas/isos NAS\n", "smb://nas/isos"), "")
    check("an empty uri never empties the file", Mounts.removeBookmark(body, ""), body)
    check("no body at all answers nothing rather than throwing", Mounts.removeBookmark("", "smb://nas/isos/"), "")

    // The two predicates that decide whether a password is demanded before a mount is attempted:
    // credentialed says one may be given, keyless says one may not be needed at all. A public key
    // opening a saved sftp place is the whole reason they differ; see AGENTS.md.
    check("a user in the authority is what makes a place able to take a password",
          Mounts.credentialed("sftp://tom@nas.test/home"), true)
    check("and an sftp place without one has no password to belong to",
          Mounts.credentialed("sftp://nas.test/home"), false)
    check("every credentialed scheme but sftp has no keyless route to try first",
          ["smb://tom@nas.test/data", "ftp://tom@nas.test/", "davs://tom@nas.test/d"].map(
              function (uri) { return Mounts.keyless(uri) }).join("|"), "false|false|false")
    check("sftp is the one scheme a key or an agent can answer, with or without a user",
          [Mounts.keyless("sftp://tom@nas.test/home"), Mounts.keyless("sftp://nas.test/")].join("|"),
          "true|true")
    check("a scheme that is not network at all answers neither",
          [Mounts.credentialed("file:///home/tom"), Mounts.keyless("file:///home/tom")].join("|"),
          "false|false")
    // Issue 194: dan's mount keeps its user; gio info may drop ,user=dan, so the repair scan picks the folder.
    check("dan@ survives mount lines, rail keys, gio info and the FUSE match", [Mounts.parseMounts("Mount(0): test on 192.168.1.75 -> smb://dan@192.168.1.75/test/\n")[0].uri, Mounts.normalize("smb://dan@192.168.1.75/test/") === Mounts.normalize("smb://dan@192.168.1.75/test"), Mounts.localPath("uri: smb://dan@192.168.1.75/test/\nlocal path: /run/user/1000/gvfs/smb-share:server=192.168.1.75,share=test,user=dan\n"), Protocols.smbFuseMatches("smb://dan@192.168.1.75/test", "/run/user/1000/gvfs/smb-share:server=192.168.1.75,share=test,user=dan"), Protocols.smbFuseMatches("smb://dan@192.168.1.75/test", "/run/user/1000/gvfs/smb-share:server=192.168.1.75,share=test"), Protocols.smbFuseMatches("smb://dan@192.168.1.75/Test", "/run/user/1000/gvfs/smb-share:server=192.168.1.75,share=test,user=dan")].join("|"), "smb://dan@192.168.1.75/test/|true|/run/user/1000/gvfs/smb-share:server=192.168.1.75,share=test,user=dan|true|false|true")
    check("the user=dan folder answers though gio info dropped the user", Protocols.smbResolve("smb://dan@192.168.1.75/test", ["/run/user/1000/gvfs/smb-share:server=192.168.1.75,share=test,user=dan"], "sam").path, "/run/user/1000/gvfs/smb-share:server=192.168.1.75,share=test,user=dan")
    check("a URI with no user takes the single matching entry", Protocols.smbResolve("smb://192.168.1.75/test", ["/run/user/1000/gvfs/smb-share:server=192.168.1.75,share=test,user=dan"], "sam").path, "/run/user/1000/gvfs/smb-share:server=192.168.1.75,share=test,user=dan")
    check("several users prefer the desktop login", Protocols.smbResolve("smb://192.168.1.75/test", ["/run/user/1000/gvfs/smb-share:server=192.168.1.75,share=test,user=dan", "/run/user/1000/gvfs/smb-share:server=192.168.1.75,share=test,user=sam"], "sam").path, "/run/user/1000/gvfs/smb-share:server=192.168.1.75,share=test,user=sam")
    check("and name themselves when the login matches none", Protocols.smbResolve("smb://192.168.1.75/test", ["/run/user/1000/gvfs/smb-share:server=192.168.1.75,share=test,user=dan", "/run/user/1000/gvfs/smb-share:server=192.168.1.75,share=test,user=sam"], "nobody").users.join(","), "dan,sam")
}
