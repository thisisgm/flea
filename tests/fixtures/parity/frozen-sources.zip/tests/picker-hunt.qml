import QtQuick
import QtTest
import Quickshell
import "flea" as Flea
import "flea/js/Keymap.js" as Keymap
import "flea/js/Picker.js" as Picker

// Drive the real picker with native Qt key events and controlled submission refusals.
ShellRoot {
    id: root
    property var pickerShell: null
    property var win: null
    property var keys: null
    property string scenario: Quickshell.env("FLEA_PICKER_HUNT_CASE")
    property int stage: 0
    property double stamp: Date.now()
    property int failures: 0
    property int checks: 0
    readonly property int burstSteps: 3
    readonly property int pollIntervalMs: 20
    readonly property int deadlineMs: 8000
    readonly property int refusalWaitMs: 400
    readonly property int settleWaitMs: 1000
    // The picker board's unavailable control, as a number of its own so a changed product token turns the check red.
    readonly property real dimmedOpacity: 0.55
    readonly property string missingFolder: "no-such-folder"
    // Sample input: FLEA_PICKER_HUNT_BASE_FILES=12, FLEA_PICKER_HUNT_EXTRA_FILES=200.
    readonly property int baseFixtureFiles: Number(Quickshell.env("FLEA_PICKER_HUNT_BASE_FILES"))
    readonly property int wideExtraFiles: Number(Quickshell.env("FLEA_PICKER_HUNT_EXTRA_FILES"))
    readonly property int pickerWidthPx: 800
    readonly property int pickerHeightPx: 410
    readonly property real chromeCenterTolerancePx: 1
    readonly property real rangeClickInsetPx: 5
    readonly property int rangeClickRowStep: 2
    readonly property int rangeClickCount: rangeClickRowStep + 1
    readonly property string folderSuffix: "/z-folder"
    readonly property int overlongNameFactor: 2
    readonly property int killSignal: 9
    property bool chromeChecked: false
    property var initiatingFocus: null
    property var movedFocus: null

    function check(label, got, want) {
        checks++
        var ok = JSON.stringify(got) === JSON.stringify(want)
        if (!ok) failures++
        console.log("PICKER_HUNT " + (ok ? "PASS " : "FAIL ") + label
            + " got=" + JSON.stringify(got) + " expected=" + JSON.stringify(want))
    }
    function finish() {
        console.log("PICKER_HUNT DONE " + checks + " checks, " + failures + " failed")
        Qt.exit(failures ? 1 : 0)
    }
    function descendants(item) {
        var out = [item]
        for (var i = 0; i < out.length; i++) {
            var kids = out[i].children || []
            for (var j = 0; j < kids.length; j++) out.push(kids[j])
        }
        return out
    }
    function sceneRect(item) {
        var point = item.mapToItem(null, 0, 0)
        return Qt.rect(point.x, point.y, item.width, item.height)
    }
    function intersects(a, b) {
        return a.x < b.x + b.width && b.x < a.x + a.width
            && a.y < b.y + b.height && b.y < a.y + a.height
    }
    function checkChromeGeometry() {
        var viewButton = descendants(win.contentItem).filter(function(item) { return item.name === "List view" })[0]
        check("real view marks exist", !!viewButton, true)
        if (!viewButton) return
        var views = sceneRect(viewButton.parent)
        var controls = viewButton.parent.parent.focusItems()
        var pathStrip = sceneRect(controls[0].parent.parent)
        var openButton = sceneRect(root.answerOpen())
        var titleStrip = sceneRect(descendants(win.contentItem).filter(function(item) { return item.objectName === "pickerAsk" })[0])
        console.log("PICKER_HUNT GEOMETRY views=" + JSON.stringify(views) + " path=" + JSON.stringify(pathStrip))
        check("view marks stay inside path strip", views.x >= pathStrip.x && views.x + views.width <= pathStrip.x + pathStrip.width
            && views.y >= pathStrip.y && views.y + views.height <= pathStrip.y + pathStrip.height, true)
        check("view marks centre within one pixel", Math.abs(views.y + views.height / 2 - pathStrip.y - pathStrip.height / 2) <= chromeCenterTolerancePx, true)
        check("view marks do not intersect title strip", intersects(views, titleStrip), false)
        check("view marks do not intersect Open button", intersects(views, openButton), false)
    }
    // The primary answer inside the answer row only; the save area holds no answer of its own.
    function answerOpen() {
        var bar = descendants(win.contentItem).filter(function(item) { return item.objectName === "pickerAnswers" })[0]
        return descendants(bar).filter(function(item) { return item.primary === true && item.tabHandle === true })[0]
    }
    function pressOpen() {
        var button = root.answerOpen()
        check("real Open button exists", !!button && button.name.indexOf("Open") === 0, true)
        if (!button) return
        check("real Open button available", button.available, true)
        keys.mouseClick(button, button.width / 2, button.height / 2, Qt.LeftButton, Qt.NoModifier, -1)
    }
    function press(key, modifiers) { keys.keyClick(key, modifiers || Qt.NoModifier, -1) }
    // A scratch Text in the status line's font and wrap mode, measured by its lines and the widest one.
    function wrapped(line, mode, text, width) {
        var probe = Qt.createQmlObject("import QtQuick; Text { textFormat: Text.PlainText }", line.parent)
        probe.font = line.font
        probe.wrapMode = mode
        probe.text = text
        probe.width = width
        probe.forceLayout()
        var measured = {lines: probe.lineCount, width: probe.contentWidth}
        probe.destroy()
        return measured
    }
    function heroItem() {
        return descendants(win.contentItem).filter(function(item) { return item.markItem !== undefined && item.captionItem !== undefined })[0]
    }
    // The listing worker dying over held rows keeps the rows and the footer error, and never draws the empty hero.
    function lostListing() {
        if (stage === 0) {
            if (!win || win.listingState !== "ready" || !win.rows.length) return
            check("a listed folder draws no hero", heroItem().visible, false)
            var listing = descendants(win.contentItem).filter(function(item) { return item.current !== undefined && typeof item.clear === "function" })[0]
            check("the picker owns a listing worker", !!listing && !!listing.current, true)
            if (!listing || !listing.current) {
                finish()
                return
            }
            listing.current.signal(root.killSignal)
            stage = 1
        } else if (win.listingFailed) {
            check("a lost listing worker is reported", win.message.indexOf("Flea stopped responding, so this folder could not be listed.") === 0 && win.messageError, true)
            check("a lost listing worker keeps its rows", win.rows.length > 0 && win.total === win.rows.length, true)
            check("a lost listing worker draws no empty hero", heroItem().visible, false)
            finish()
        }
    }
    // A listing that fails while it loads holds no rows, so it reads as empty with the hero and the error, never as loading.
    function failedOpen() {
        if (stage === 0) {
            if (!win || win.listingState !== "ready" || !win.rows.length) return
            win.open(win.path + "/" + root.missingFolder)
            stage = 1
        } else if (win.listingFailed) {
            check("a failed open holds no rows", win.total === 0 && win.rows.length === 0, true)
            check("a failed open reads as empty", win.listingState, "empty")
            check("a failed open draws the hero", heroItem().visible, true)
            check("a failed open reports its error", win.messageError && win.message.length > 0, true)
            finish()
        }
    }
    function checkCollisionWrap() {
        var form = descendants(win.contentItem).filter(function(item) { return item.statusItem !== undefined })[0]
        check("save form exposes its status line", !!form, true)
        if (!form) return
        var line = form.statusItem
        var plain = line.text.replace(/\u200b/g, "")
        check("collision line is shown", line.visible && plain.indexOf(win.saveName) === 0, true)
        // One pixel under the sentence's own width pushes only the last word onto a second line.
        var narrow = Math.floor(wrapped(line, Text.NoWrap, line.text, line.width).width) - 1
        var reference = wrapped(line, Text.WordWrap, line.text, narrow)
        check("collision sentence wraps onto two lines", reference.lines, 2)
        check("collision sentence breaks between words", wrapped(line, line.wrapMode, line.text, narrow), reference)
        var name = "x".repeat(Math.ceil(root.overlongNameFactor * line.width))
        var overlong = wrapped(line, line.wrapMode, name + plain.slice(win.saveName.length), line.width)
        check("one unbroken name stays inside the card", overlong.width <= line.width, true)
        check("one unbroken name breaks inside itself", overlong.lines > 1, true)
    }
    // Enters at doubleActivate; delegate tap capture: native SP02 (tests/picker-native.py:401-406); Picker.sameTap: tests/js/picker.js:164-167.
    function doubleActivateCursor() {
        var row = win.rowFor(win.cursorIndex)
        check("double activation sees real row", !!row, true)
        if (!row) return
        var path = Picker.rowPath(win.path, row.n)
        win.doubleActivate(win.cursorIndex, path, path)
        check("double activation checks mark with backend", win.markRequest > 0, true)
        var sent = win.nextCheck
        win.doubleActivate(win.cursorIndex, path, path)
        check("busy double activation sends no second check", win.nextCheck, sent)
        check("busy double activation keeps Space refusal", win.message, "Selection is still being checked.")
    }

    function focusRefusal() {
        if (!win || win.listingState !== "ready" || !win.rows.length || (win.saving && !win.saveReady)) return
        if (stage === 0) {
            win.cursorIndex = 0
            win.focusView()
            if (!win.viewItem().activeFocus) return
            if (scenario === "refuse-validate") {
                // Space marks the cursor file in a multiple request, the only way a user reaches a selection to validate.
                if (win.marks.length === 0) {
                    if (!win.markRequest) press(Qt.Key_Space)
                    return
                }
                check("refuse-validate request takes several files", win.req.multiple, true)
                check("Space marked the cursor file", win.marks.map(function(mark) { return mark.path }), [win.path + "/a.txt"])
            }
            if (win.saving) {
                var form = descendants(win.contentItem).filter(function(item) { return item.fieldItem !== undefined && item.askedName !== undefined })[0]
                form.fieldItem.forceActiveFocus()
            } else if (scenario === "refuse-button") {
                root.answerOpen().forceActiveFocus()
            }
            initiatingFocus = win.contentItem.Window.window.activeFocusItem
            press(Qt.Key_Return)
            if (scenario === "refuse-collision") {
                check("collision Enter returns focus to Filename", win.contentItem.Window.window.activeFocusItem === form.fieldItem, true)
                check("collision does not start submission", win.submitting, false)
                check("collision keeps request open", win.answered, false)
                checkCollisionWrap()
                finish()
                return
            }
            check("Return starts submission", win.submitting, true)
            check("submission steps focus to Cancel", win.contentItem.Window.window.activeFocusItem.name, "Cancel")
            if (scenario === "refuse-moved" || scenario === "refuse-returned") {
                press(Qt.Key_Tab)
                movedFocus = win.contentItem.Window.window.activeFocusItem
                check("Tab moves focus off stepped Cancel", movedFocus.name === "Cancel", false)
                if (scenario === "refuse-returned") {
                    press(Qt.Key_Backtab, Qt.ShiftModifier)
                    movedFocus = win.contentItem.Window.window.activeFocusItem
                    check("user returns focus to Cancel", movedFocus.name, "Cancel")
                }
            } else if (scenario === "refuse-cancel") {
                press(Qt.Key_Return)
                check("Cancel answers pending submission", win.answered, true)
            }
            stage = 1
            stamp = Date.now()
        } else if (stage === 1 && Date.now() - stamp > root.refusalWaitMs && !win.submitting && !win.markRequest) {
            check("refused submission keeps request open", win.answered, false)
            check("refused submission keeps permission message", win.message, "Could not inspect " + win.path + "/a.txt: permission denied")
            check("refused submission keeps error styling", win.messageError, true)
            if (scenario === "refuse-moved" || scenario === "refuse-returned") {
                check("refusal preserves user's moved focus", win.contentItem.Window.window.activeFocusItem === movedFocus, true)
                win.focusView()
            } else {
                check("refusal restores initiating focus", win.contentItem.Window.window.activeFocusItem === initiatingFocus, true)
                if (scenario === "refuse-mark" || scenario === "refuse-validate")
                    check("refusal returns focus to view", win.viewItem().activeFocus, true)
            }
            console.log("PICKER_HUNT RETRY Enter after refusal")
            press(Qt.Key_Enter, Qt.KeypadModifier)
            stage = 2
            stamp = Date.now()
        }
    }

    Connections {
        target: root.win
        function onAnsweredChanged() {
            if (root.scenario.indexOf("refuse-") !== 0 || !root.win.answered) return
            Qt.callLater(function() {
                if (root.scenario !== "refuse-cancel" && root.stage !== 2) return
                root.check("answered request never restores initiating focus", root.win.contentItem.Window.window.activeFocusItem.name, "Cancel")
                console.log("PICKER_HUNT DONE " + root.checks + " checks, " + root.failures + " failed")
            })
        }
    }

    Component.onCompleted: {
        var comp = Qt.createComponent("flea/PickerWindow.qml")
        if (comp.status !== Component.Ready) {
            console.log("PICKER_HUNT FAIL compile " + comp.errorString())
            Qt.exit(1)
            return
        }
        pickerShell = comp.createObject(root)
        win = pickerShell.pickerWin
        win.width = root.pickerWidthPx
        win.height = root.pickerHeightPx
        keys = Qt.createQmlObject("import QtTest; TestEvent {}", win.contentItem)
    }

    Timer {
        interval: root.pollIntervalMs
        running: true
        repeat: true
        onTriggered: {
            if (Date.now() - root.stamp > root.deadlineMs) {
                root.check("probe completes", "timeout stage " + stage, "complete")
                root.finish()
                return
            }
            if (!root.chromeChecked) {
                if (!win || win.contentItem.width !== root.pickerWidthPx || win.contentItem.height !== root.pickerHeightPx) return
                root.checkChromeGeometry()
                root.chromeChecked = true
            }
            if (scenario.indexOf("refuse-") === 0) { root.focusRefusal(); return }
            if (scenario === "lost-listing") {
                root.lostListing()
                return
            }
            if (scenario === "failed-open") {
                root.failedOpen()
                return
            }
            if (win && scenario === "empty" && win.listingState === "empty") {
                root.check("empty listing disables Open", win.canAccept, false)
                root.check("empty listing draws the hero", root.heroItem().visible, true)
                var emptyButton = root.descendants(win.contentItem).filter(function(item) { return item.name === "Open" && item.available !== undefined })[0]
                root.check("empty Open opacity", emptyButton.opacity, root.dimmedOpacity)
                root.finish()
                return
            }
            if (!win || win.listingState !== "ready" || !win.rows.length) return
            if (stage === 0) {
                if (win.saving && !win.saveReady) return
                root.check("requested key preset loaded", Flea.ViewState.keysPreset, Quickshell.env("FLEA_PICKER_HUNT_PRESET"))
                if (scenario === "folder") {
                    win.cursorIndex = 0
                    win.focusView()
                    root.check("folder disables Open", win.canAccept, false)
                    var folderButton = root.descendants(win.contentItem).filter(function(item) { return item.name === "Open" && item.available !== undefined })[0]
                    root.check("folder Open opacity", folderButton.opacity, root.dimmedOpacity)
                    root.press(Qt.Key_Return)
                    root.stage = 1
                    root.stamp = Date.now()
                    return
                }
                var rowIndex = win.rows.findIndex(function(row) { return row.n === "a.txt" })
                if (rowIndex < 0) {
                    root.check("missing row a.txt", rowIndex >= 0, true)
                    root.finish()
                    return
                }
                win.cursorIndex = rowIndex + win.held
                win.focusView()
                if (!win.viewItem().activeFocus) return
                root.check("real cursor is a file", win.rowFor(win.cursorIndex).n, "a.txt")
                // The press pumps the event loop and the 20 ms poll would re-enter stage 0 and press twice, so the stage is claimed first.
                root.stage = 1
                root.stamp = Date.now()
                if (scenario.indexOf("cursor-") === 0) {
                    root.check("cursor file enables Open", win.canAccept, true)
                    console.log("PICKER_HUNT INPUT Return action="
                        + Keymap.lookup(Qt.Key_Return, "", Qt.NoModifier, "listing"))
                    if (scenario === "cursor-button") root.pressOpen()
                    else root.press(scenario === "cursor-enter" ? Qt.Key_Enter : Qt.Key_Return, scenario === "cursor-enter" ? Qt.KeypadModifier : Qt.NoModifier)
                } else if ((scenario === "all" || scenario === "all-wide")) {
                    root.check("Ctrl+A maps to selectAll", Keymap.lookup(Qt.Key_A, "a", Qt.ControlModifier, "listing"), "selectAll")
                    root.press(Qt.Key_A, Qt.ControlModifier)
                } else if (scenario === "range-up" || scenario === "range-click") {
                    var index = win.cursorIndex
                    if (scenario === "range-up") {
                        win.cursorIndex = index + (win.viewMode === "grid" ? win.viewItem().columns : 1)
                        root.press(Qt.Key_Up, Qt.ShiftModifier)
                    } else {
                        var cell = win.viewItem().itemAtIndex(index + root.rangeClickRowStep)
                        keys.mouseClick(cell, cell.width - root.rangeClickInsetPx, cell.height / 2, Qt.LeftButton, Qt.ShiftModifier, -1)
                    }
                } else if (scenario === "range-burst") {
                    for (var burst = 0; burst < root.burstSteps; burst++) root.press(Qt.Key_Down, Qt.ShiftModifier)
                } else if (scenario === "range" || scenario === "range-shrink") {
                    root.check("Shift+Down maps to extendDown", Keymap.lookup(Qt.Key_Down, "", Qt.ShiftModifier, "listing"), "extendDown")
                    root.press(Qt.Key_Down, Qt.ShiftModifier)
                } else if (scenario === "save-marks" || scenario === "single-marks") {
                    root.press(Qt.Key_Space)
                    root.press(Qt.Key_Down, Qt.ShiftModifier)
                    root.press(Qt.Key_A, Qt.ControlModifier)
                } else if (scenario === "remember") {
                    win.setView(win.viewMode === "grid" ? "list" : "grid")
                } else if (scenario === "double-mark") {
                    root.press(Qt.Key_Space)
                } else if (scenario === "control" || (scenario === "marked-open" || scenario === "marked-enter")) {
                    root.press(win.viewMode === "grid" ? Qt.Key_Right : Qt.Key_Down)
                    root.check("arrow moves the real cursor", win.rowFor(win.cursorIndex).n, "b.txt")
                    root.press(Qt.Key_Space)
                }
                root.stamp = Date.now()
                return
            }
            if (stage === 1 && Date.now() - root.stamp > root.settleWaitMs && !win.markRequest) {
                if (scenario.indexOf("cursor-") === 0) {
                    root.check("Return answers cursor file", win.answered, true)
                    console.log("PICKER_HUNT MESSAGE " + win.message)
                } else if ((scenario === "all" || scenario === "all-wide")) {
                    root.check("Ctrl+A marks shown files", win.marks.length, scenario === "all-wide" ? root.baseFixtureFiles + root.wideExtraFiles : root.baseFixtureFiles)
                    if (scenario === "all-wide") root.check("select-all reaches beyond held window", win.rows.length < win.marks.length, true)
                } else if (scenario === "range-up" || scenario === "range-click") {
                    var wanted = scenario === "range-click" ? root.rangeClickCount : win.viewMode === "grid" ? win.viewItem().columns + 1 : 2
                    root.check("Shift+Up or click marks range", win.marks.length, wanted)
                } else if (scenario === "folder") {
                    root.check("Enter walks into cursor folder", win.path.endsWith(root.folderSuffix), true)
                    root.check("folder navigation does not answer", win.answered, false)
                } else if (scenario === "range" || scenario === "range-burst" || scenario === "range-shrink") {
                    var stride = win.viewMode === "grid" ? win.viewItem().columns : 1
                    var rangeCount = scenario === "range-burst" ? root.burstSteps * stride + 1 : stride + 1
                    root.check("Shift+Down marks cursor range", win.marks.length, rangeCount)
                    if (scenario === "range-shrink") {
                        root.press(Qt.Key_Up, Qt.ShiftModifier)
                        root.stage = 2
                        root.stamp = Date.now()
                        return
                    }
                } else if (scenario === "save-marks" || scenario === "single-marks") {
                    root.check("save mode never marks files", win.marks.length, 0)
                    var cells = root.descendants(win.viewItem()).filter(function(item) { return item.listingIndex !== undefined })
                    root.check("box probe sees real delegates", cells.length > 0, true)
                    root.check("save or single-file rows have no boxes", cells.every(function(cell) { return cell.markable === false }), true)
                } else if (scenario === "remember") {
                    root.check("view switch updates remembered state", Flea.ViewState.pickerView, win.viewMode)
                } else if (scenario === "double-mark") {
                    root.check("Space retains first mark", win.marks.map(function(mark) { return mark.path }), [win.path + "/a.txt"])
                    root.press(win.viewMode === "grid" ? Qt.Key_Right : Qt.Key_Down)
                    root.check("double click targets unmarked b.txt", win.rowFor(win.cursorIndex).n, "b.txt")
                    root.doubleActivateCursor()
                    root.stage = 2
                    root.stamp = Date.now()
                    return
                } else if (scenario === "control" || (scenario === "marked-open" || scenario === "marked-enter")) {
                    root.check("Space marks one real file", win.marks.length, 1)
                    if ((scenario === "marked-open" || scenario === "marked-enter")) {
                        if (win.marks.length > 0)
                            root.check("marked file is b.txt", win.marks[0].path.split("/").pop(), "b.txt")
                        root.press(win.viewMode === "grid" ? Qt.Key_Right : Qt.Key_Down)
                        root.check("cursor moves off marked file", win.rowFor(win.cursorIndex).n, "c.txt")
                        var preset = Flea.ViewState.keysPreset
                        root.check("Return follows current preset", Keymap.lookup(Qt.Key_Return, "", Qt.NoModifier, "listing"), preset === "mac" ? "rename" : "open")
                        root.press(scenario === "marked-enter" ? Qt.Key_Enter : Qt.Key_Return, scenario === "marked-enter" ? Qt.KeypadModifier : Qt.NoModifier)
                        root.stage = 2
                        root.stamp = Date.now()
                        return
                    }
                }
                root.finish()
            }
            if (stage === 2 && Date.now() - root.stamp > root.settleWaitMs) {
                if (scenario === "double-mark") {
                    if (win.markRequest) return
                    root.check("double click adds b.txt and retains a.txt", win.marks.map(function(mark) { return mark.path }), [win.path + "/a.txt", win.path + "/b.txt"])
                    root.check("marking double click leaves request open", win.answered, false)
                    root.check("marking double click never starts submission", win.submitting, false)
                    root.doubleActivateCursor()
                    root.stage = 3
                    root.stamp = Date.now()
                    return
                } else if (scenario === "range-shrink") root.check("range shrink keeps only anchor", win.marks.length, 1)
                else root.check("marked Return or Enter writes portal answer", win.answered, true)
                root.finish()
            }
            if (stage === 3 && Date.now() - root.stamp > root.settleWaitMs && !win.markRequest) {
                root.check("second double click unmarks only b.txt", win.marks.map(function(mark) { return mark.path }), [win.path + "/a.txt"])
                root.check("unmarking double click leaves request open", win.answered, false)
                root.check("unmarking double click never starts submission", win.submitting, false)
                root.finish()
            }
        }
    }
}
